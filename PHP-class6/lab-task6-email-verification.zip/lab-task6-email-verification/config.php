<?php
// Configuration for email
return [
    'host' => 'smtp.gmail.com', // Your SMTP server
    'username' => 'nishoahmed570@gmail.com', // Your email address
    'password' => 'ppbjzytgfzlxdase', // Your email password
    'port' => 587, // Typically 587 for TLS or 465 for SSL
    'from_email' => 'nishoahmed570@gmail.com', // Sender email address
    'from_name' => 'Nisho Ahmed', // Sender name
];
?>
